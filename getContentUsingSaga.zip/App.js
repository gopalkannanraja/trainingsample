import React from 'react';
import { Text, View, StyleSheet, Image } from "react-native";
import { Provider } from 'react-redux';
import store from './src/store';
import SwipeViewWithRedux from './SwipeViewWithRedux';

export default class App extends React.Component {
    render() {
        return (
            <Provider store={store}>
                <View style={styles.container}>
                    <SwipeViewWithRedux />
                </View>
            </Provider>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#009688',
        justifyContent: 'center', 
        alignContent: 'center'
    }
});