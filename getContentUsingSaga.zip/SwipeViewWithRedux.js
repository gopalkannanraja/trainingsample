import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import GestureRecognizer from 'react-native-swipe-gestures';
import * as actions from './src/actions/detailAction';

class SwipeViewWithRedux extends React.Component {
    static defaultProps = {
        content: {}
    }

    static propTypes = {
        content: PropTypes.objectOf(PropTypes.object)
    }

    onSwipeLeft = (gestureState) => {
        // this.setState({ myText: 'You swiped left!' });
        console.log('###this is onSwipeLeft', gestureState);
    }

    onSwipeRight = (gestureState) => {
        // this.setState({ myText: 'You swiped right!' });
        console.log('###this is onSwipeRight', gestureState);
    }

    componentDidMount() {
        this.props.actions.getContent(1);
        console.log('###componentDidMount');
    }

    render() {
        const config = {
            velocityThreshold: 0.3,
            directionalOffsetThreshold: 80
        };
        return (
            <GestureRecognizer
                onSwipeLeft={(state) => this.onSwipeLeft(state)}
                onSwipeRight={(state) => this.onSwipeRight(state)}
                config={config}
                style={{ flex: 1, backgroundColor: '#fff' }} >
                <Text>onSwipe callback received gesture</Text>
            </GestureRecognizer>
        );
    }

}

const mapStateToProps = state => ({
    content: state.data
});

const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators(actions, dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(SwipeViewWithRedux);