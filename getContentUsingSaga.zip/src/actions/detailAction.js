import { GET_CONTENT, GET_CONTENT_SUCCESS, GET_CONTENT_ERROR } from '../actionTypes/detailActionType';

export const getContent = params => ({
    type: GET_CONTENT,
    payload: params
});
