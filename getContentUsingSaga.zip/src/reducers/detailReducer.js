import * as types from '../actionTypes/detailActionType';

export default function detailReducer(state = {}, action) {
    switch (action.type) {
        case types.GET_CONTENT:
            return { state, isLoading: true };
        case types.GET_CONTENT_SUCCESS: {
            const { data } = action;
            return { state, data, isLoading: false };
        }
        case types.GET_CONTENT_ERROR:
            return { state, data: action.error, isLoading: false };
        default:
            return state;
    }
}