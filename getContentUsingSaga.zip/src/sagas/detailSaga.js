import { call, put, takeLatest } from 'redux-saga/effects';
import * as types from '../actionTypes/detailActionType';

function* getDetail() {
    console.log('###sagaaction', action);
    try {
        let data = yield fetch(`http://api.bible.quickinnews.com/v1/text/english/old/Genesis/Chapter%201`)
        .then(r => r.json());
        yield put({type: types.GET_CONTENT_SUCCESS, data});
    } catch(error) {
        yield put({type: types.GET_CONTENT_ERROR, error});
    }
}

export default function* watchDetailSaga() {
    yield takeLatest(types.GET_CONTENT, getDetail);
}