import {createStore, applyMiddleware} from 'redux';
import detailReducer from '../reducers/detailReducer';
import createSagaMiddleware from 'redux-saga';
import watchDetailSaga from '../sagas/detailSaga';

const sagaMiddleware = createSagaMiddleware();
const store = createStore(
    detailReducer,
    applyMiddleware(sagaMiddleware)
);
sagaMiddleware.run(watchDetailSaga);

export default store;