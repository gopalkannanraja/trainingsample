import React, { Component } from 'react';
import { View, StyleSheet, Text } from 'react-native';

class DetailsScreen extends Component {
    render() {
        return (
            <View>
                <Text> This is details page.. </Text>
            </View>
        );
    }
}

export default DetailsScreen;