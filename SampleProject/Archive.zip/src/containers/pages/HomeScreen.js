import React, { Component } from 'react';
import { View, StyleSheet, Text } from 'react-native';

class HomeScreen extends Component {
    render() {
        return (
            <View>
                <Text> This is home page.. </Text>
            </View>
        );
    }
}

export default HomeScreen;