import React, { Component } from "react";
import { View, Text } from "react-native";

class Search extends Component {

    render() {
        return (
            <View>
                <Text>This is Search</Text>
            </View>
        );
    }
}

export default Search;
