import { put, takeLatest } from "redux-saga/effects";
import * as actionCreators from "../actionCreators/search"
import { SEARCH_PRODUCTS } from "../actionTypes/search";

let URI = "http://10.100.205.124:4000";

function* getProducts(action) {
    try {
        let products = yield fetch(`${URI}/products?q=${action.text}`).then(r => r.json());
        console.log('###searchsagaproducts', products);
        yield put(actionCreators.searchProductsSuccess(action.text, products))
    } catch (error) {
        yield put(actionCreators.searchProductsFailure(action.text, error))
    }
}

export function* productSearchWatchers() {
    console.log('##productSearchWatchers');
    yield takeLatest(SEARCH_PRODUCTS, getProducts)
}