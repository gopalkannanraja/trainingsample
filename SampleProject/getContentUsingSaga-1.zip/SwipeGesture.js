import React from 'react';
import { Text, View, StyleSheet, Image } from "react-native";
import GestureRecognizer, { swipeDirections } from 'react-native-swipe-gestures';

export default class SwipeGesture extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            myText: 'I\'m ready to get swiped!',
            gestureName: 'none',
            backgroundColor: '#fff'
        };
    }

    onSwipeLeft(gestureState) {
        this.setState({ myText: 'You swiped left!' });
    }

    onSwipeRight(gestureState) {
        this.setState({ myText: 'You swiped right!' });
    }

    render() {
        const config = {
            velocityThreshold: 0.3,
            directionalOffsetThreshold: 80
        };

        return (
            <GestureRecognizer
                onSwipeLeft={(state) => this.onSwipeLeft(state)}
                onSwipeRight={(state) => this.onSwipeRight(state)}
                config={config}
                style={{
                    flex: 1,
                    backgroundColor: this.state.backgroundColor
                }}
            >
                <Text>{this.state.myText}</Text>
                <Text>onSwipe callback received gesture: {this.state.gestureName} வணக்கம்</Text>
            </GestureRecognizer>
        );
    }
}