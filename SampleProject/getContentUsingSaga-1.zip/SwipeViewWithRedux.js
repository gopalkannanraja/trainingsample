import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, View, Text, WebView, ActivityIndicator } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import GestureRecognizer from 'react-native-swipe-gestures';
import * as actions from './src/actions/detailAction';

class SwipeViewWithRedux extends React.Component {
    static defaultProps = {
        content: [],
        isLoading: false
    }

    static propTypes = {
        content: PropTypes.arrayOf(PropTypes.object),
        isLoading: PropTypes.bool
    }

    onSwipeLeft = (gestureState) => {
        // this.setState({ myText: 'You swiped left!' });
        console.log('###this is onSwipeLeft', gestureState);
        this.props.actions.getContent(2);
    }

    onSwipeRight = (gestureState) => {
        // this.setState({ myText: 'You swiped right!' });
        console.log('###this is onSwipeRight', gestureState);
        this.props.actions.getContent(3);
    }

    componentDidMount() {
        this.props.actions.getContent(1);
    }

    render() {
        const config = {
            velocityThreshold: 0.3,
            directionalOffsetThreshold: 80
        };
        const {content, isLoading} = this.props;
        console.log('###render', content);
        console.log('###isLoading', isLoading);
        return (
            <View>
                <GestureRecognizer
                    onSwipeLeft={(state) => this.onSwipeLeft(state)}
                    onSwipeRight={(state) => this.onSwipeRight(state)}
                    config={config}
                    style={{ flex: 1, backgroundColor: '#fff' }} >
                    {isLoading ? <ActivityIndicator size="large" color="#0000ff" />: <WebView source={{html: content[0].contents}}/> }
                </GestureRecognizer>
            </View>
        );
    }

}

const mapStateToProps = state => ({
    content: state.data !== undefined ? state.data.details: [],
    isLoading: state.isLoading
});

const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators(actions, dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(SwipeViewWithRedux);